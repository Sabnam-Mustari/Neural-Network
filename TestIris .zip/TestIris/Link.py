import numpy as np
import math

#tau = 12
#v= 7
minDelayF = 1
maxDelayF = 16
#class to define the basic Asynchronous Spiking Neuronal model, that will be used as a unit function
#in networks
#contains constructor for individual neurons, and any function applied to individual neurons
class Link:

	def __init__(self, terminals, prevLayerN,threshold1, tau1):
		global minDelayF, maxDelayF, v, tau
		v= threshold1
		tau = tau1
		timestep = 0.1
		tmin = (timestep/tau) -1
		tmax = tau + maxDelayF
		#the weights and delays associated with a connection
		# between a presynaptic neuron i and the current neuron j

		#"Fast modifications" paper, page 3972 eqs (11) and (12)
		# Set tmin = timestep, tmax=tau+dmax
		wMin = (v * tau)/(terminals*prevLayerN*self.lifFunction(timestep))
		wMax = (v * tau)/(terminals*prevLayerN*self.lifFunction(tmax))

		#print("Min W:", wMin, "Max W:", wMax)

		self.weights = wMin + np.random.uniform(wMin, wMax, terminals)
		#self.weights = wMin + np.random.uniform(1, v, terminals)
		self.delays = np.array(range(1,terminals+1))
		wMin = np.min(self.weights)
		#print("Min W:", wMin)
		#self.weights = np.random.uniform(1, 20, terminals)
		#self.delays = np.random.uniform(1, 16, terminals)

	#a standard spike response function describing a postsynaptic potential
	#creates a leaky-integrate-and-fire neuron
	@classmethod
	def lifFunction(self, time):
		#global tau

		if time >= 0:
			div = float(time) / tau
			return div * math.exp(1 - div)
		else:
			return 0

	@classmethod
	def normWeights(self, weights):
		print ('before ', weights)
		minW = np.amin(weights)
		print( minW)
		maxW = np.amax(weights)
		print (maxW)
		out = (weights - float(minW))/(maxW-minW)
		print( 'after ', out)
		return (weights - minW)/(maxW-minW)