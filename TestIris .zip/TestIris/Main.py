import numpy as np
import pickle 
from SNNetwork import *
from DataProc import *
from SpikeProp import *
from Link import *
import sys


def main():
    file = str(sys.argv[1])
    SEED = sys.argv[2]
    seed = int(sys.argv[3])
    ALPHA1 = sys.argv[4]
    alpha = float(sys.argv[5])
    #DELTA1 = sys.argv[6]
    #deltaT = int(sys.argv[7])
    EPOCH1  = sys.argv[6]
    epochs = int(sys.argv[7])
    HIDNEURON1 = sys.argv[8]
    hidNeuron = int(sys.argv[9])
    TAU1 = sys.argv[10]
    tau = int(sys.argv[11])	
    TERMINAL1 = sys.argv[12]
    terminal = int(sys.argv[13])
    TRESHOLD1 = sys.argv[14]
    threshold = int(sys.argv[15])
    TYPEA = sys.argv[16]
    typeA = int(sys.argv[17])
    TYPEB = sys.argv[18]
    typeB = int(sys.argv[19])
    TYPEC = sys.argv[20]
    typeC = int(sys.argv[21])

    #print('FileName:', file)
    # add an extra column as the bias
    replacements = {'Iris-setosa': '1', 'Iris-versicolor': '2', 'Iris-virginica': '3', ',':' '}
    with open(file) as infile, open('iris.data', 'w') as outfile:
        for line in infile:
            for src, target in replacements.items():
                line = line.replace(src, target)
            outfile.write(line)
    data, target = DataProc.readData('iris.data', 4)
	
    minValue = np.min(np.min(data, axis=1), axis=0)
    maxvalue = np.max(np.max(data, axis=1), axis=0)
    inputdata = DataProc.addBias(data)
    deltaT = maxvalue - minValue
    delta = 0
    #tyes = maxvalue + 2
    sample= data.shape[0]
    sample=int(sample / 2)
    trainingInput = inputdata[:sample, :]
    trainingTarget = target[:sample, :]

    testingInput = inputdata[sample:, :]
    testingTarget = target[sample:, :]

    inputNeurons = data.shape
    netLayout = np.asarray([hidNeuron, 1])
	# set the number of inhibitory neurons to set in the network
    inhibN = 1	

    net = SNNetwork(netLayout, inputNeurons[1], terminal, inhibN,threshold, tau )
    # net.displaySNN()
    #AsyncSN.setThreshold(tau,threshold)
    #Link.setTau(tau, threshold)
    SpikeProp.setTimeLimit(deltaT, tau, terminal)
    SpikeProp.train(net, trainingInput, trainingTarget, alpha, epochs, sample, delta, typeA, typeB, typeC )
    filename = 'IrisNet.sav'
    pickle.dump(net, open(filename, 'wb'))
	# net.displaySNN()
    #print("*****************************Training Completed*********************************")
    loaded_model = pickle.load(open(filename, 'rb'))
    SpikeProp.test(loaded_model, testingInput, testingTarget, alpha, sample, delta, typeA, typeB, typeC )


#needed in order to be ale to run main 
if __name__ == "__main__":
	main()