import numpy as np
import pandas
import pickle
from Network import *
from DataProc import *
from irisSpikeProp import *
import sys

def main():
    replacements = {'Iris-setosa': '1', 'Iris-versicolor': '2', 'Iris-virginica': '3', ',': ' '}

    with open('iris.txt') as infile, open('iris.data', 'w') as outfile:
        for line in infile:
            for src, target in replacements.items():
                line = line.replace(src, target)
            outfile.write(line)


    data, target = DataProc.readData('iris.data', 4) # number of input layer neuron = 4

    minValue = np.min(np.min(data, axis=1), axis=0)
    maxvalue = np.max(np.max(data, axis=1), axis=0)
    print(minValue, maxvalue)

    # add an extra column as the bias
    inputdata = DataProc.addBias(data)
    sample = data.shape[0]
    sample=int(sample / 2)
    trainingInput = inputdata[:sample, :]
    trainingTarget = target[:sample, :]

    testingInput = inputdata[sample:, :]
    testingTarget = target[sample:, :]

    learningRate = 0.01
    deltaT = maxvalue - minValue
    timeStep = 0.1
    epochs = 5
    hidNeuron = 8
    tau = 12
    threshold = 7
    terminals = 16
    # set the number of inhibitory neurons to set in the network
    inhibN = 1
    OutNeurons = 1
    typeA = 4; typeB =5; typeC = 6
    inputNeurons = data.shape
    netLayout = np.asarray([hidNeuron, OutNeurons])

    irisSpikeProp(OutNeurons,deltaT, tau, terminals,timeStep)

    net = Network(netLayout, inputNeurons[1], terminals, inhibN,threshold, tau, timeStep)
    #irisSpikeProp.setTimeLimit(deltaT, tau, terminals)
    net.displaySNN()
    irisSpikeProp.train(net, trainingInput, trainingTarget, learningRate, epochs, sample, deltaT, typeA, typeB, typeC)
    # save the model to disk
    filename = 'IrisNet.sav'
    pickle.dump(net, open(filename, 'wb'))
    print("*****************************Training Completed*********************************")
    loaded_model = pickle.load(open(filename, 'rb'))
    irisSpikeProp.test(loaded_model, testingInput, testingTarget, learningRate, sample, deltaT, typeA, typeB, typeC)
    #net.displaySNN()

if __name__ == "__main__":
	main()