from matplotlib import pyplot as mp
from decimal import *
import numpy as np
from numpy import genfromtxt
import math
import pandas



DeltaT = 40
m = 7
mu = []
arraylist = []
beta = 1


#WBC
Imin=1
Imax = 10
x = np.linspace(Imin, Imax, Imax-Imin+2)
InputDataRange = Imax-Imin
sig =  InputDataRange/(beta*(m-2))
for i in range(m):
    mu.append(Imin+(2*i-1)*InputDataRange/(2*(m-2)))
p = len(mu)

class RF:

    @classmethod
    def codingFN(self,wbcfile,timeStep1):
        global  timeStep
        timeStep = timeStep1
        #wbc = genfromtxt(wbcfile, delimiter=',')
        wbc = pandas.read_csv(wbcfile).as_matrix()
        #wbc = wbc[:, 1:]  # First column(regarded as identity number)
        train_Data = wbc[:, :9]  # 200 sample has been taken as training data
        row, column = train_Data.shape
        target_Data = wbc[:, 9:10]  # last column represent target output
        #for i in range(0, 1):
        for i in range(0, len(train_Data)):
            self.trainingSet(i,train_Data)
            arraylist.append(target_Data[i])
        '''
        for i in range(0, p):
            mp.plot(self.gaussian(x, mu[i], sig))
        mp.show()
        '''
        with open('encode_wbc.txt', 'w') as fo:
            fo.write(','.join([str(n) for n in arraylist]))
        fo.close()


    @classmethod
    def gaussian(self, x, mu, sig):
        out= (1-np.exp(-(x-mu)*(x-mu)/(2*sig*sig)))* (DeltaT+1)
    #    print(x,out)
        return out
    #    return np.exp(-np.power(x - mu, 2.) / (2 * np.power(sig, 2.))) * DeltaT
    @classmethod
    def intersection(self,x_pos, row):
        for k in range(0, p):
            y = RF.gaussian(x_pos, mu[k], sig)
          #  bd = Decimal(y)
            output = round(y,0)
            #arraylist.append(float("{0:.2f}".format(output * timeStep)))

            if (output  <= DeltaT):
                arraylist.append(float("{0:.2f}".format(output)))
            else:
               arraylist.append(4)

        return arraylist

    # ---------------------------draw vertical line----------------------------
    @classmethod
    def drawline(self, x_pos):
        return mp.axvline(x_pos, ymin=0, ymax=1, linewidth=2, color='black')

    @classmethod
    def trainingSet(self, x,train_Data):
        pattern = train_Data[x:x + 1, :]  # for getting xth row input data to Tr_Set(Training Set)
        #print('Dataset: ',pattern)
        row, column = pattern.shape
        for j in range(column):
            x_pos = pattern[0][j]
        #    x_pos = value
            RF.drawline(x_pos)
            point = RF.intersection( x_pos, j)

        return (point)

    #print(' Training Dataset:\n', arraylist)
