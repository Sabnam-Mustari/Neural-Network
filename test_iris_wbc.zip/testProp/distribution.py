from matplotlib import pyplot as mp
from decimal import *
import numpy as np
import matplotlib.pyplot as plt
import math
import functools
import pandas
import textwrap

wbc = pandas.read_csv('data.txt').as_matrix()
#iris = np.genfromtxt('iris.txt', delimiter=',')

wbc = wbc[:, 1:]  # First column(regarded as identity number) and lasr column (regarded as target value)has been dropped from dataset
train_Data = wbc[:200, :]  # 200 sample has been taken as training data
row, column = train_Data.shape
target_Data = wbc[:200, 9:10]  # last column represent target output

# ---------------------------------draw Gaussian distribution----------------------------------

A2 = 4
mu = []
sig = 1 / (1.5 * 12)
x = np.linspace(0, .9, 110)
mu =[0.09, .18, .27, .36, .45, .54, .63, .72, .81]
p=len(mu)

def gaussian(x, mu, sig):
    return np.exp(-np.power(x - mu, 2.) / (2 * np.power(sig, 2.))) * A2

for i in range(0, p):
    mp.plot(gaussian(x, mu[i], sig))

arraylist = []
spikeop = np.zeros([10, p])
spiketime = np.zeros([10, p])

#--------------------- intersection point between line and Gaussian distribution-------------------------
'''
The intersection function return the crossing point among each straight line and gaussion distribution curve.
'''

def intersection(x_pos,row):
    for k in range(0, p):
        y=gaussian(x[x_pos], mu[k], sig)
        bd=Decimal(y)
        output = round(bd, 2)

        if(output>0):
           arraylist.append (float("{0:.2f}".format(y)))
           spikeop[row][k] = float("{0:.1f}".format(y))
           #spiketime[row][k] = 1
        else:
            arraylist.append(0)
            spikeop[row][k] = 0
            #spiketime[row][k] = 0
    arraylist.append('\n')
    return spikeop


# ---------------------------draw vertical line----------------------------
def drawline(x_pos):
    return mp.axvline(x_pos, ymin=0, ymax=1,linewidth = 2, color =  'black')
'''
trainingSet function is receiving a value for x from network that means this xth row now going to network as training set.
This function convert each value of xth into 14 spike time by calling intersection function.
we draw straight line for each value position of xth row dataset. The intersection function return the crossing point
among each straight line and gaussion distribution curve.
'''
def trainingSet(x):
    pattern = train_Data[x:x+1, :]       # for getting xth row input data to Tr_Set(Training Set)
    #print('Dataset: ',pattern)
    row, column = pattern.shape
    for j in range(column):
        value= pattern[0][j]
        x_pos=(value *10)
        drawline(x_pos)
        point=intersection(x_pos,j)

    return (intersection(x_pos,j))

for i in range(0, len(train_Data)):
    trainingSet(i)


print(' Training Dataset:\n',arraylist)
with open ('encoding.txt', 'w') as fo:
    fo.write(','.join([str(n) for n in arraylist]))


fo.close()
'''
def insert_newlines(string, every=64):
    lines = []
    for i in range(0, len(string), every):
        lines.append(string[i:i+every])
    return '\n'.join(lines)



thefile = open('encoding.txt', 'w')
for item in arraylist:
    thefile.write("%s" % item)
    i = 1
    if item == item *10:
      thefile.write("\n" )
    i += 1
'''
#spike = insert_newlines(arraylist)
mp.xlabel('Feature Value')
mp.ylabel('Receptive Field Neuron Response')
#mp.show()
#IH_weight(9,8)