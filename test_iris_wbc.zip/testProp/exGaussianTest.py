import numpy as np
import pandas
import pickle
from SNNetwork import *
from DataProc import *
from SpikeProp import *
import sys

def main():
    data, target = DataProc.readData('train.data', 9)
	# data, labels = DataProc.readData('data/traindata5.data',2)

    # add an extra column as the bias
    inputdata = DataProc.addBias(data)

    sample = data.shape[0]
    sample=int(sample / 2)
    trainingInput = inputdata[:sample, :]
    trainingTarget = target[:sample, :]

    testingInput = inputdata[sample:, :]
    testingTarget = target[sample:, :]

    learningRate = 0.01
    deltaT = 10
    epochs = 2
    hidNeuron = 8
    tau = 12
    terminals = 16
    tno = 12 # it will go 10- 38 range
    yesGapNo =3 # will go 1 to 38-tno
    inputNeurons = data.shape
    netLayout = np.asarray([hidNeuron, 1])

    # set the number of inhibitory neurons to set in the network
    inhibN = 1
    threshold = 7

    #AsyncSN.setThreshold(threshold, tau)

    SpikeProp.setTimeLimit(deltaT, tau, terminals)
    net = SNNetwork(netLayout, inputNeurons[1], terminals, inhibN,threshold, tau)
    #net.displaySNN()
    SpikeProp.train(net, trainingInput, trainingTarget, learningRate, epochs, sample, tno, yesGapNo)
    # save the model to disk
    filename = 'finalNet.sav'
    pickle.dump(net, open(filename, 'wb'))
    print("*****************************Training Completed*********************************")
    loaded_model = pickle.load(open(filename, 'rb'))
    SpikeProp.test(loaded_model, testingInput, testingTarget, learningRate, sample, tno, yesGapNo)
    #net.displaySNN()

if __name__ == "__main__":
	main()