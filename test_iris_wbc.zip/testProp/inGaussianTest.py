import numpy as np
import pandas
import pickle

import algorithm
from SNNetwork import *
from DataProc import *
from RF import *
from SpikeProp import *
from algorithm import *
import sys

#global timeStep

def main():

    timeStep = 0.1
    RF.codingFN('maligant.txt',timeStep)
    replacements = {'[2]': '2\n', '[4]': '4\n',  ',': ' '}

    with open('encode_wbc.txt') as infile, open('file.data ', 'w') as outfile:
        for line in infile:
            for src, target in replacements.items():
                line = line.replace(src, target)
            outfile.write(line)

    data, target = DataProc.readData('file.data', 63)
    #print(target)
    minValue = np.min(np.min(data, axis=1), axis=0)
    maxvalue = np.max(np.max(data, axis=1), axis=0)
    #print('minvalue',minValue,'maxvalue:', maxvalue)
    inputdata = DataProc.addBias(data)

    sample = data.shape[0]
    sample=int(sample / 2)
    trainingInput = inputdata[:sample, :]
    trainingTarget = target[:sample, :]

    testingInput = inputdata[sample:, :]
    testingTarget = target[sample:, :]

    learningRate = 0.01

    deltaT = (maxvalue - minValue)/timeStep
    epochs = 5
    hidNeuron = 8
    tau = 7
    terminals = 16
    firstSpikeOut=5
    lastSpikeOut = 6
    tyes = 6  # it will go 10- 38 range
    tno =5  # will go 1 to 38-tno
    inputNeurons = data.shape
    netLayout = np.asarray([hidNeuron, 1])

    # set the number of inhibitory neurons to set in the network
    inhibN = 1
    threshold = 5

    #AsyncSN.setThreshold(threshold, tau)

    algorithm.setTimeLimit(lastSpikeOut)
    net = SNNetwork(netLayout, inputNeurons[1], terminals, inhibN, threshold, tau)
    #net.displaySNN()
    algorithm.train(net, trainingInput, trainingTarget, learningRate, epochs, sample, tyes, tno)
    # save the model to disk
    filename = 'finalNet.sav'
    pickle.dump(net, open(filename, 'wb'))
    print("*****************************Training Completed*********************************")
    loaded_model = pickle.load(open(filename, 'rb'))
    algorithm.test(loaded_model, testingInput, testingTarget, learningRate, sample, tyes, tno)
    #net.displaySNN()

if __name__ == "__main__":
	main()