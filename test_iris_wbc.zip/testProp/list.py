matrix = [[0 for i in range(2)] for j in range(5)]
matrix[4][0]= 44
#print(matrix)


values=[]

values.append([0,0])
values.append([0,0])
values.append([0,0])
values.append([0,0])
values.append([0,0])

values[0][1]= 5
values[1][1]= 1 +values[0][1]
mu = []
for i in range(1, 7):
    k= 1 + ((2 * i - 3) / 2) * 9 / 7
    mu.insert(i, k)
print(mu)
