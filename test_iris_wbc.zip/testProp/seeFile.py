import scipy.io
import numpy as np

f = open("wbc.txt", "r")
g = open("fixed.txt", "w")

for line in f:
    if line.strip():
        g.write("\t".join(line.split()[1:-1]) + "\n")

f.close()
g.close()