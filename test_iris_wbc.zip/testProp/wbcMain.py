import numpy as np
import pandas
import pickle
from SNNetwork import *
from DataProc import *
from wbcSpikeProp import *
import sys

def main():

    data, target = DataProc.readData('wbcFull.data', 9) # number of input layer neuron = 9
    #data, target = DataProc.readData('maligant.data', 9)
    #data, target = DataProc.readData('bening.data', 9)
	# data, labels = DataProc.readData('data/traindata5.data',2)
    # add an extra column as the bias
    inputdata = DataProc.addBias(data)
    minValue = np.min(np.min(data, axis=1), axis=0)
    maxvalue = np.max(np.max(data, axis=1), axis=0)
    print(minValue, maxvalue)

    deltaT = maxvalue - minValue
    fullSample = data.shape[0]
    sample=int(fullSample / 2)
    trainingInput = inputdata[:sample, :]
    trainingTarget = target[:sample, :]

    testingInput = inputdata[sample:, :]
    testingTarget = target[sample:, :]
    timeStep = 1
    learningRate = 0.01
    epochs = 2
    hidNeuron = 8
    tau = 11
    threshold = 2
    terminals = 16

    tyes = 7  # it will go 10- 38 range
    tno =8
    inputNeurons = data.shape
    outputNeuron = 1
    netLayout = np.asarray([hidNeuron, outputNeuron])

    # set the number of inhibitory neurons to set in the network
    inhibN = 1
    wbcSpikeProp(outputNeuron)
    wbcSpikeProp.setTimeLimit(deltaT, tau, terminals)
    net = SNNetwork(netLayout, inputNeurons[1], terminals, inhibN,threshold, tau, timeStep)
    #net.displaySNN(outputNeuron)

    wbcSpikeProp.train(net, trainingInput, trainingTarget, learningRate, epochs, tyes, tno)
    # save the model to disk
    filename = 'finalNet.sav'
    pickle.dump(net, open(filename, 'wb'))
    print("*****************************Training Completed *********************************")
    loaded_model = pickle.load(open(filename, 'rb'))
    wbcSpikeProp.test(loaded_model, testingInput, testingTarget, learningRate, sample, tyes, tno)
    #net.displaySNN()

if __name__ == "__main__":
	main()