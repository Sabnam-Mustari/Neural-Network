# voice-recognition
baby emotional voice recognition using matlab.
